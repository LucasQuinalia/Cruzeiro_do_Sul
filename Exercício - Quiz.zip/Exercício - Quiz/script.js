let btn1 = document.querySelector("#btn1");
let btn2 = document.querySelector("#btn2");
let btn3 = document.querySelector("#btn3");
let btn4 = document.querySelector("#btn4");
let btn5 = document.querySelector("#btn5");

btn1.addEventListener("click", function(){
    let resp1 = document.querySelector("#resp1");
    if(document.getElementById('1789').checked) {
        resp1.innerHTML = "Resposta correta!"
    }
    else {
        resp1.innerHTML = "Resposta errada!"
    }
});

btn2.addEventListener("click", function(){
    let resp2 = document.querySelector("#resp2");
    if(document.getElementById('1991').checked) {
        resp2.innerHTML = "Resposta correta!"
    }
    else {
        resp2.innerHTML = "Resposta errada!"
    }
});

btn3.addEventListener("click", function(){
    let resp3 = document.querySelector("#resp3");
    if(document.getElementById('1969').checked) {
        resp3.innerHTML = "Resposta correta!"
    }
    else {
        resp3.innerHTML = "Resposta errada!"
    }
});

btn4.addEventListener("click", function(){
    let resp4 = document.querySelector("#resp4");
    if(document.getElementById('1945').checked) {
        resp4.innerHTML = "Resposta correta!"
    }
    else {
        resp4.innerHTML = "Resposta errada!"
    }
});

btn5.addEventListener("click", function(){
    let resp5 = document.querySelector("#resp5");
    if(document.getElementById('1500').checked) {
        resp5.innerHTML = "Resposta correta!"
    }
    else {
        resp5.innerHTML = "Resposta errada!"
    }
});
