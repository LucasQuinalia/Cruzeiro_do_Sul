// 1 – CRIE UM PROGRAMA QUE LEIA 05 VALORES E IMPRIMA ELES EM ORDEM CRESCENTE.
// 2 - CRIE UM PROGRAMA QUE LEIA 03 VALORES E CALCULE O QUADRADO
// 3 – CRIE UM PROGRAMA QUE LEIA 02 VALORES E IMPRIMA A MEDIA.
// 4 – CRIE UM PROGRAMA QUE LEIA UM VALOR E INFORME SE ELE É PAR.
"use strict";

document.querySelector("#ord").addEventListener('click', 
function() {
    let vetor1 = [];
    let n1 = parseFloat(document.querySelector("#n1").value);
    let n2 = parseFloat(document.querySelector("#n2").value);
    let n3 = parseFloat(document.querySelector("#n3").value);
    let n4 = parseFloat(document.querySelector("#n4").value);
    let n5 = parseFloat(document.querySelector("#n5").value);
    vetor1.push(n1);
    vetor1.push(n2);
    vetor1.push(n3);
    vetor1.push(n4);
    vetor1.push(n5);
    document.querySelector("#resul1").innerHTML = vetor1.sort();
});

document.querySelector("#quad").addEventListener('click', 
function() {
    let n6 = parseFloat(document.querySelector("#n6").value);
    let n7 = parseFloat(document.querySelector("#n7").value);
    let n8 = parseFloat(document.querySelector("#n8").value);
    document.querySelector("#resul2").innerHTML = "Primeiro valor: " + (n6 * n6) + "<br>Segundo valor: " + (n7 * n7) + "<br>Terceiro valor: " + (n8 * n8);
});

document.querySelector("#media").addEventListener('click', 
function() {
    let n9 = parseFloat(document.querySelector("#n9").value);
    let n10 = parseFloat(document.querySelector("#n10").value);
    document.querySelector("#resul3").innerHTML = (n9 + n10) / 2;
}); 

document.querySelector("#verificar").addEventListener('click', 
function() {
    let n11 = document.querySelector("#n11").value;
    if (n11 % 2 === 0) {
        document.querySelector("#resul4").innerHTML = "Par!";
    }
    else {
        document.querySelector("#resul4").innerHTML = "Ímpar!";
    }
});
